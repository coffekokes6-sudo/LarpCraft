// LarpCraft server: accounts + password-protected rooms, saved to data.json
const{WebSocketServer}=require('ws'),fs=require('fs'),cr=require('crypto');
const F='data.json';let D={users:{},rooms:{}};try{D=JSON.parse(fs.readFileSync(F))}catch{}
let tm=0;const save=()=>{if(!tm)tm=setTimeout(()=>{tm=0;fs.writeFileSync(F,JSON.stringify(D))},2000)};
process.on('SIGINT',()=>{fs.writeFileSync(F,JSON.stringify(D));process.exit()});
const hp=(p,s)=>cr.scryptSync(String(p),s,32).toString('hex'),eq=(a,b)=>cr.timingSafeEqual(Buffer.from(a),Buffer.from(b));
const live=new Map(),num=v=>Number.isFinite(v)?v:0;let nid=1;
const cl=o=>o&&{skin:String(o.skin),hair:String(o.hair),shirt:String(o.shirt),pants:String(o.pants)};
new WebSocketServer({port:process.env.PORT||8080,maxPayload:4096}).on('connection',ws=>{
 const c={id:nid++,send:o=>ws.readyState===1&&ws.send(JSON.stringify(o))},err=m=>c.send({t:'err',m});let fails=0,rk=null;
 const others=f=>{for(const o of live.get(rk)||[])if(o!==c)f(o)};
 ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
  if(m.t==='auth'){const k=String(m.u||'').toLowerCase();
   if(!/^[a-z0-9_]{3,16}$/.test(k)||String(m.p||'').length<6)return err('Name: 3-16 letters/numbers/_ · password: 6+ characters');
   if(m.reg){if(D.users[k])return err('Name already taken');const s=cr.randomBytes(16).toString('hex');D.users[k]={name:String(m.u),salt:s,hash:hp(m.p,s)}}
   else{const u=D.users[k];if(!u||!eq(hp(m.p,u.salt),u.hash)){if(++fails>4)ws.close();return err('Wrong name or password')}}
   try{D.users[k].chr=cl(m.chr)||D.users[k].chr}catch{}
   c.me=k;c.name=D.users[k].name;c.chr=D.users[k].chr;save();return c.send({t:'auth'})}
  if(!c.me)return;
  if((m.t==='create'||m.t==='join')&&!rk){const rn=String(m.name||'').trim().slice(0,24),k=rn.toLowerCase();
   if(!rn||String(m.pw||'').length<3)return err('Room name + password (3+ chars) required');
   let R=D.rooms[k];
   if(m.t==='create'){if(R)return err('Room already exists');let s=String(m.seed||'').trim(),n=0;
    if(!s)n=Math.floor(Math.random()*1e9);else if(/^-?\d{1,9}$/.test(s))n=+s;else for(const ch of s)n=(Math.imul(n,31)+ch.charCodeAt(0))|0;
    const sl=cr.randomBytes(16).toString('hex');R=D.rooms[k]={name:rn,owner:c.me,salt:sl,hash:hp(m.pw,sl),seed:n,flat:false,mods:{},pos:{}}}
   else if(!R||!eq(hp(m.pw,R.salt),R.hash)){if(++fails>4)ws.close();return err('Wrong room name or password')}
   const S=live.get(k)||new Set();if([...S].some(o=>o.me===c.me))return err('You are already in this room');
   live.set(k,S);rk=k;c.R=R;c.send({t:'joined',seed:R.seed,flat:R.flat,mods:R.mods,pos:R.pos[c.me]||null});
   for(const o of S)if(o.x!==undefined)c.send({t:'p',id:o.id,name:o.name,chr:o.chr,x:o.x,y:o.y,z:o.z,yaw:o.yaw});S.add(c);save();return}
  if(!rk)return;
  if(m.t==='pos'){Object.assign(c,{x:num(m.x),y:num(m.y),z:num(m.z),yaw:num(m.yaw)});c.R.pos[c.me]=[c.x,c.y,c.z,c.yaw];
   others(o=>o.send({t:'p',id:c.id,name:c.name,chr:c.chr,x:c.x,y:c.y,z:c.z,yaw:c.yaw}));save()}
  else if(m.t==='blk'){const{x,y,z,id}=m;if(![x,y,z,id].every(Number.isInteger)||y<1||y>63||id<0||id>16||id===6||Math.abs(x)>1e6||Math.abs(z)>1e6)return;
   c.R.mods[x+','+y+','+z]=id;others(o=>o.send({t:'blk',x,y,z,id}));save()}});
 ws.on('close',()=>{if(rk){live.get(rk).delete(c);others(o=>o.send({t:'left',id:c.id}))}});ws.on('error',()=>{})});
console.log('LarpCraft server on port '+(process.env.PORT||8080));
