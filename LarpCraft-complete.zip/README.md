# LarpCraft

- www/    -> hra (index.html)
- server/ -> multiplayer server: cd server && npm install && npm start
             v hre zadaj ws://TVOJA_IP:8080
- GitHub Actions (.github/workflows/build.yml) zbuilduje APK:
  Actions -> posledny run -> Artifacts -> LarpCraft-debug-apk
